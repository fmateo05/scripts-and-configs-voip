define(function(require) {
	var $ = require('jquery'),
		monster = require('monster');

	var app = {

		requests: {
		},

		subscribe: {
			'voip.failover.render': 'failoverRender'
		},

		conferenceViewerRender: function(args) {
			var self = this,
				parent = args.parent || $('#ws_content'),
				callback = args.callback;

			monster.pub('common.failover.renderPopup', {
				container: parent,
				viewType: 'pbx',
				callbackAfterRender: callback
			});
		}
	};

	return app;
});
