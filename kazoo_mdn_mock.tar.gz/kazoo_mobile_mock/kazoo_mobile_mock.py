from fastapi import FastAPI, Request, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
import httpx
import uuid
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mobile-mock-api")

app = FastAPI(title="Kazoo cb_mobile Mock API")

# Habilitar CORS para permitir peticiones desde Monster UI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------------------------
# Manejador genérico para solicitudes OPTIONS (Preflight requests)
# -------------------------------------------------------------------
@app.options("/{full_path:path}")
async def options_handler(full_path: str):
    return {"status": "ok"}

# Dirección de tu servicio PyHSS
PYHSS_API_URL = "http://127.0.0.1:8080/api/subscriber"

# -------------------------------------------------------------------
# Manejo del consumo de datos / voz de la cuenta:
# GET /v2/accounts/{account_id}/usage
# -------------------------------------------------------------------
@app.get("/v2/accounts/{account_id}/usage")
async def get_account_usage(account_id: str, request: Request):
    logger.info(f"Petición de consumo (usage) recibida para la cuenta: {account_id}")

    # Estructura JSON estándar esperada por Monster UI Mobile
    return {
        "status": "success",
        "data": {
            "per_mdn": {
                "18292672505": 150000000,       # 150 MB en bytes
                "+18292672505": 150000000,      # Formato con signo + por si acaso
                "16312403922": 200000000,
                "+16312403922": 200000000
            },
            "total_usage": 350000000 ,
            "data_usage": {
                "used_bytes": 0,
                "total_bytes": 10737418240  # 10 GB de cuota límite (ejemplo)
            },
            "voice_usage": {
                "used_seconds": 0,
                "total_seconds": 3600
            },
            "sms_usage": {
                "used_count": 0,
                "total_count": 500
            }
        },
        "request_id": str(uuid.uuid4())
    }
@app.get("/v2/accounts/{account_id}/devices/{device_id}/usage")
@app.get("/accounts/{account_id}/devices/{device_id}/usage")
async def get_device_usage(account_id: str, device_id: str):

    return {
        "status": "success",
        "data": {
            "device_id": device_id,
            "mdn": "+18292672505",
            "usage": 150000000,  # Bytes consumidos
            "cap": 10000000000   # Límite en bytes
        }
    }

# -------------------------------------------------------------------
# Manejo del endpoint global de validez de IMEI/ESN:
# GET /v2/devices/{device_id}/validity
# -------------------------------------------------------------------
@app.get("/v2/devices/{imei}/validity")
async def check_device_validity(imei: str, request: Request):
    logger.info(f"Petición GET de validación recibida para IMEI/ESN: {imei}")

    # Estructura del JSON que espera el frontend de Monster UI
    return {
        "status": "success",
        "data": {
            "valid": True,
            "imei": str(imei),
            "device_type": "4G/LTE/5G Device",
            "status": "cleared",
            "sim_compatible": True,
            "make": "Open5GS Terminal",
            "model": "Generic VoLTE Device"
        },
        "request_id": str(uuid.uuid4())
    }



# -------------------------------------------------------------------
# 1. Endpoint para VALIDACIÓN DE IMEI / ESN / MEID
# Ruta: POST o PUT /v2/accounts/{account_id}/mobile/validate
# -------------------------------------------------------------------
@app.api_route("/v2/accounts/{account_id}/mobile/validate", methods=["POST", "PUT"])
async def validate_device(account_id: str, request: Request):
    body = await request.json()
    data = body.get("data", {})
    
    imei = data.get("device_id") or data.get("imei") or data.get("esn")
    logger.info(f"Petición de validación de IMEI/ESN para la cuenta {account_id}: {imei}")

    # Validación básica de longitud para IMEI (15 dígitos) o ESN/MEID
    if not imei or len(str(imei)) < 11:
        return {
            "status": "error",
            "message": "Invalid IMEI/ESN length",
            "error": "400"
        }

    # Respuesta estructurada exactamente como la espera Monster UI
    return {
        "status": "success",
        "data": {
            "valid": True,
            "imei": str(imei),
            "device_type": "4G/LTE/5G Device",
            "status": "cleared",
            "sim_compatible": True,
            "make": "Open5GS Terminal",
            "model": "Generic VoLTE Mobile"
        },
        "request_id": str(uuid.uuid4())
    }

# -------------------------------------------------------------------
# 2. Endpoint para LISTAR DISPOSITIVOS MÓVILES
# Ruta: GET /v2/accounts/{account_id}/mobile
# -------------------------------------------------------------------
@app.get("/v2/accounts/{account_id}/mobile")
async def list_mobile_devices(account_id: str):
    # Aquí puedes consultar la DB de PyHSS/MongoDB para listar los suscriptores existentes
    return {
        "status": "success",
        "data": [],
        "request_id": str(uuid.uuid4())
    }

# -------------------------------------------------------------------
# 3. Endpoint para CREAR/APROVISIONAR DISPOSITIVO MÓVIL
# Ruta: PUT /v2/accounts/{account_id}/mobile
# -------------------------------------------------------------------
@app.put("/v2/accounts/{account_id}/mobile")
async def create_mobile_device(account_id: str, request: Request, x_auth_token: str = Header(None)):
    body = await request.json()
    data = body.get("data", {})
    
    mobile = data.get("mobile", {})
    imsi = mobile.get("imsi")
    ki = mobile.get("ki")
    opc = mobile.get("opc")
    msisdn = mobile.get("msisdn") or data.get("number")
    imei = mobile.get("imei")

    if not imsi or not ki or not opc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Faltan parámetros requeridos: IMSI, Ki o OPC."
        )

    logger.info(f"Aprovisionando nueva SIM en PyHSS - IMSI: {imsi}, MSISDN: {msisdn}")

    # Payload para la API de PyHSS
    pyhss_payload = {
        "imsi": str(imsi),
        "key": str(ki),
        "opc": str(opc),
        "amf": "8000",
        "sqn": 0,
        "msisdn": str(msisdn) if msisdn else "",
        "imei": str(imei) if imei else "",
        "apn": "internet"
    }

    # Enviar registro a PyHSS
    async with httpx.AsyncClient() as client:
        try:
            pyhss_res = await client.post(PYHSS_API_URL, json=pyhss_payload, timeout=5.0)
            logger.info(f"Respuesta de PyHSS: {pyhss_res.status_code}")
        except Exception as e:
            logger.error(f"Error conectando con PyHSS API: {e}")

    # Retornar el objeto con formato Crossbar a Monster UI
    device_id = str(uuid.uuid4())
    return {
        "status": "success",
        "data": {
            "id": device_id,
            "name": data.get("name", f"SIM-{imsi[-4:]}"),
            "device_type": "mobile",
            "enabled": True,
            "account_id": account_id,
            "mobile": {
                "imsi": imsi,
                "iccid": mobile.get("iccid", ""),
                "msisdn": msisdn,
                "imei": imei
            }
        },
        "request_id": str(uuid.uuid4())
    }
