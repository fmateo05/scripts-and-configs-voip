
function myFunction() {
	 var data = $("#output").text();
	 //var data = document.getElementById("output");
	//data.append("output", output2);

$.ajax({
	    data: data,
            type: "GET",
            url: "https://www.aurus.com.do/contact_me.php",
            cache: false,
            contentType: false,
            processData: false,
            success: function(returned_data) {
                // $('#output').html(data);
		  alert("Server said: " + returned_data);
                 $('#success').html(returned_data);
            }
        });
}
document.getElementById("call").onclick = function() {myFunction()};	

