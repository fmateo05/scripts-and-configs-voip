window.APP_CONFIG = {
  VITE_APP_NAME: "IP Voice",
  VITE_APP_ENV: "production",
  VITE_DEBUG: "false",

  VITE_API_BASE_URL: "https://portal.bevoip.net:8443/v2",
  VITE_API_PROVISIONER: "https://phoneprov.bevoip.net:7443/api/",
//  VITE_API_SOCKET_URL: "wss://ws.zpbx.ipvoice.one",
  VITE_API_DIRECT_ROUTING: "disabled",
  VITE_API_TALKTO: "disabled",
  VITE_API_WEBRTC: "disabled",

  VITE_AUTH_TIMEOUT_MS: "5000",
  VITE_POLLING_SECONDS: "30",
  VITE_MAX_ATTEMPTS: "1",

  VITE_API_PAGE_SIZE: "50",
  VITE_MAX_RANGE_SECONDS: "2682000",

  VITE_ALLOW_DEVICE_ADDITION: "true",

  VITE_CURRENCY_CODE: "AUD",

 // VITE_DOCS_API_URL: "https://api-docs.ipvoice.one/api"
};
