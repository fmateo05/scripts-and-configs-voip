from fastapi import FastAPI, Request, Query, Response, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import time

# app = FastAPI(title="Kazoo / Monster UI Mobile Mock API")
app = FastAPI(redirect_slashes=False)

# Permitir solicitudes CORS desde el frontend Monster UI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inventario de números disponibles (Spares Pool)
SPARES_POOL = [
    "+18295550101",
    "+18295550102",
    "+18295550103",
    "+18295550104",
    "+18295550105"
]

# -------------------------------------------------------------------
# BASE DE DATOS EN MEMORIA (MOCK DATA)
# -------------------------------------------------------------------
ACCOUNT_ID = "4409b1f0000000000000000000000000"

# -------------------------------------------------------------------
# ESTRUCTURA DE LA CUENTA (/accounts/{accountId})
# -------------------------------------------------------------------
# Objeto de respuesta unificado con todas las claves requeridas
MOCK_ACCOUNT_RESPONSE = {
    "status": "success",
    "data": {
        "id": "4409b1f0000000000000000000000000",
        "name": "Cuenta Pruebas Mobile",
        "realm": "ims.mnc001.mcc370.3gppnetwork.org",
        # REQUERIDO: Evita el error 'reading blocking'
        "data": {
            "blocking": {
                "cap": 10000000000  # 10 GB
            },
            "throttling": {
                "cap": 8000000000,
                "rate": "128k"
            }
        },
        # REQUERIDO: Evita el error 'reading features'
        "device_defaults": {
            "data": {
                "blocking": {
                    "cap": 5000000000
                },
                "throttling": {
                    "cap": 4000000000,
                    "rate": "64k"
                }
            },
            "features": ["mms", "tethering"]
        }
    }
}



# Endpoint 1: Backend Carrier/Top API (/accounts/{account_id})
@app.get("/accounts/{account_id}")
async def top_get_account(account_id: str):
    return MOCK_ACCOUNT_RESPONSE

# Endpoint 2: Kazoo Core API (/v2/accounts/{account_id})
@app.get("/v2/accounts/{account_id}")
async def kazoo_get_account(account_id: str):
    return MOCK_ACCOUNT_RESPONSE

# -------------------------------------------------------------------
# ESTRUCTURA DE DISPOSITIVOS (/accounts/{accountId}/devices)
# -------------------------------------------------------------------
devices_db = {
    "dev_mob_001": {
        "id": "dev_mob_001",
        "name": "Felipe - Device 1",
        "mdn": "18292672505",
        # REQUERIDO: Garantizar 'model.manufacturer' y 'model.name'
        "model": {
            "manufacturer": "Apple",
            "name": "iPhone 15",
            "number": "A3106"
        },
        # REQUERIDO: Estructura de datos por dispositivo
        "data": {
            "blocking": {
                "cap": 10000000000
            },
            "throttling": {
                "cap": 8000000000,
                "rate": "128k"
            }
        },
        "subscription": {
            "mdn": "18292672505",
            "esn": "89014103211118501001",
            "features": ["mms", "tethering"],
            "suspended": False,
            "plan": "Unlimited Plan"
        },
        "voice": {
            "sip": {
                "realm": "ims.mnc001.mcc370.3gppnetwork.org",
                "username": "user_mob001",
                "password": "secretpassword"
            }
        }
    }
}


users_db = [
    {
        "id": "usr_001",
        "first_name": "Felipe",
        "last_name": "Mateo",
        "email": "felipe@example.com"
    }
]

voicemail_boxes_db = [
    {
        "id": "vm_001",
        "name": "Buzón Principal",
        "owner_id": "usr_001",
        "mailbox": "100"
    }
]

callflows_db = [
    {
        "id": "cf_001",
        "name": "Callflow Móvil +1 (829) 267-2505",
        "numbers": ["18292672505"],
        "type": "mobile",
        "owner_id": "usr_001",
        "flow": {
            "module": "device",
            "data": {"id": "dev_mob_001"}
        }
    }
]

ports_db = []

# -------------------------------------------------------------------
# ENDPOINTS KAZOO CORE (/v2/accounts/...)
# -------------------------------------------------------------------



@app.get("/v2/accounts/{account_id}/devices")
async def kazoo_list_devices(account_id: str, request: Request):
    """Lista dispositivos Kazoo filtrando por filter_mobile.mdn si aplica"""
    mdn_filter = request.query_params.get("filter_mobile.mdn")
    data_list = list(devices_db.values())
    if mdn_filter:
        data_list = [d for d in data_list if d.get("mdn") == mdn_filter]
    return {"status": "success", "data": data_list}

@app.get("/v2/accounts/{account_id}/users")
async def kazoo_list_users(account_id: str):
    return {"status": "success", "data": users_db}

@app.get("/v2/accounts/{account_id}/vmboxes")
async def kazoo_list_voicemail_boxes(account_id: str):
    return {"status": "success", "data": voicemail_boxes_db}

@app.get("/v2/accounts/{account_id}/callflows")
async def kazoo_list_callflows(account_id: str):
    return {"status": "success", "data": callflows_db}

@app.get("/v2/accounts/{account_id}/callflows/search")
async def kazoo_search_callflows_by_number(account_id: str, value: str = Query(...)):
    """Busca callflows por número de teléfono (mdn)"""
    matched = [cf for cf in callflows_db if value in cf.get("numbers", [])]
    return {"status": "success", "data": matched}

@app.post("/v2/accounts/{account_id}/callflows")
async def kazoo_create_callflow(account_id: str, request: Request):
    body = await request.json()
    new_cf = body.get("data", {})
    new_cf["id"] = f"cf_{int(time.time())}"
    callflows_db.append(new_cf)
    return {"status": "success", "data": new_cf}

# -------------------------------------------------------------------
# ENDPOINTS TOP / CARRIER MOBILE (/accounts/...)
# -------------------------------------------------------------------

@app.get("/accounts/{account_id}")
async def top_get_account(account_id: str):
    return {"status": "success", "data": account_data}

@app.get("/accounts/{account_id}/usage")
async def top_get_account_usage(account_id: str):
    """Suministra el uso total y consumo por línea (MDN)"""
    return {
        "status": "success",
        "data": {
            "total": 3500000000   # ~3.5 GB consumidos
            },
            "total_usage": 150000000
    }

def get_random_mdn() -> str:
    """Genera un MDN aleatorio válido si el pool está vacío."""
    suffix = "".join([str(random.randint(0, 9)) for _ in range(7)])
    return f"+1829{suffix}"

@app.post("/v2/accounts/{account_id}/devices")
@app.post("/accounts/{account_id}/devices/activate")
async def activate_mobile_device(
    account_id: str,
    payload: dict = Body(...)
):
    # 1. Obtener los parámetros enviados desde el frontend
    selection_type = payload.get("selection_type", "auto") # "manual", "random", "spare"
    requested_mdn = payload.get("mdn")
    
    assigned_mdn = ""

    # CASO A: El usuario seleccionó o escribió un número específico
    if selection_type == "manual" and requested_mdn:
        assigned_mdn = requested_mdn

    # CASO B: Tomar un número del grupo de Spares (Inventario)
    elif selection_type == "spare" or (selection_type == "auto" and SPARES_POOL):
        if SPARES_POOL:
            assigned_mdn = SPARES_POOL.pop(0)  # Extrae y asigna el primer spare disponible
        else:
            assigned_mdn = get_random_mdn()     # Fallback si no quedan spares

    # CASO C: Generar un número aleatorio (Random)
    elif selection_type == "random":
        assigned_mdn = get_random_mdn()

    # Fallback si nada coincide
    else:
        assigned_mdn = get_random_mdn()

    # 2. Generar la estructura del dispositivo asignando el MDN dinámico
    device_id = f"dev_{random.randint(1000, 9999)}"
    clean_mdn = assigned_mdn.replace("+", "")

    new_device = {
        "id": device_id,
        "name": payload.get("name", "New Mobile Device"),
        "device_type": "mobile",
        "enabled": True,
        "mdn": clean_mdn,
        "esn": payload.get("esn", f"8901410{random.randint(1000000000, 9999999999)}"),
        "mobile": {
            "mdn": assigned_mdn,
            "esn": payload.get("esn", "")
        },
        "subscription": {
            "mdn": assigned_mdn,
            "features": ["mms", "tethering"],
            "suspended": False
        },
        "model": payload.get("model", {"manufacturer": "Generic", "name": "Mobile Device"})
    }

    # Guardar en CouchDB o en la memoria Mock aquí...

    return {
        "status": "success",
        "data": new_device
    }


@app.get("/accounts/{account_id}/devices")
async def top_list_devices(account_id: str):
    """Monster UI convierte esta lista con _.keyBy(data, 'id')"""
    return {"status": "success", "data": list(devices_db.values())}

@app.get("/accounts/{account_id}/devices/{device_id}")
async def top_get_device(account_id: str, device_id: str):
    device = devices_db.get(device_id)
    if not device:
        return Response(status_code=404, content='{"error": 404, "message": "Device Not Found"}')
    return {"status": "success", "data": device}

@app.get("/accounts/{account_id}/devices/{device_id}/usage")
async def top_get_device_usage(account_id: str, device_id: str):
    """Devuelve las métricas horarias de uso de datos para las tablas/gráficos"""
    return {
        "status": "success",
        "data": {
            "hourly": [
                {"timestamp": 1727220000, "usage": 150000000},
                {"timestamp": 1727223600, "usage": 320000000},
                {"timestamp": 1727227200, "usage": 85000000}
            ]
        }
    }

@app.get("/devices/{esn}/validity")
async def top_validate_device(esn: str):
    """Valida el ESN/IMEI para el flujo de activación"""
    return {
        "status": "success",
        "data": {
            "valid": True,
            "sim_required": True,
            "reason": "available"
        }
    }

@app.get("/locality/coverage/{postal_code}")
async def top_check_coverage(postal_code: str):
    """Suministra la cobertura según código postal"""
    return {
        "status": "success",
        "data": {
            "5g": "excellent",
            "lte": "good",
            "3g": "fair"
        }
    }

# -------------------------------------------------------------------
# ENDPOINTS PORTABILIDAD (PORTING IN)
# -------------------------------------------------------------------

@app.get("/accounts/{account_id}/ports/in")
async def top_list_porting(account_id: str):
    return {"status": "success", "data": ports_db}

@app.get("/ports/{mdn}/validity")
async def top_validate_porting(mdn: str, carrier: str = "sprint"):
    return {
        "status": "success",
        "data": {
            "valid": True,
            "mdn": mdn
        }
    }


# Estructura JSON válida de Google Maps Geocoding API
MAPS_GEOCODE_MOCK_DATA = {
    "results": [
        {
            "address_components": [
                {"long_name": "11519", "short_name": "11519", "types": ["postal_code"]},
                {"long_name": "Santo Domingo", "short_name": "SD", "types": ["locality", "political"]},
                {"long_name": "Dominican Republic", "short_name": "DO", "types": ["country", "political"]}
            ],
            "formatted_address": "Santo Domingo 11519, Dominican Republic",
            "geometry": {
                "bounds": {
                    "northeast": {"lat": 18.5000, "lng": -69.9000},
                    "southwest": {"lat": 18.4600, "lng": -69.9500}
                },
                "location": {"lat": 18.4861, "lng": -69.9312},
                "location_type": "APPROXIMATE",
                "viewport": {
                    "northeast": {"lat": 18.5000, "lng": -69.9000},
                    "southwest": {"lat": 18.4600, "lng": -69.9500}
                }
            },
            "place_id": "ChIJ1X8X8xR_r44R_mock_santo_domingo",
            "postcode_localities": ["Santo Domingo"],
            "types": ["postal_code"]
        }
    ],
    "status": "OK"
}

# 2. Interceptor HTTP directo en el ciclo de la petición (Bypassea el enrutador de FastAPI)
@app.middleware("http")
async def fix_slash_and_maps_interceptor(request: Request, call_next):
    # Normalizar la ruta ignorando slashes finales y query strings
    raw_path = request.url.path.rstrip("/")

    # Evaluar si la Petición es para la API de Maps
    if raw_path.endswith("/maps/api/geocode/json") or "/maps/api/geocode" in raw_path:
        return JSONResponse(
            status_code=200,
            content=MAPS_GEOCODE_MOCK_DATA,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "*"
            }
        )

    return await call_next(request)

# 3. Mapear explícitamente ambas variantes por si pasa del middleware
@app.api_route("/maps/api/geocode/json", methods=["GET", "POST", "OPTIONS"])
@app.api_route("/maps/api/geocode/json/", methods=["GET", "POST", "OPTIONS"])
async def maps_fallback(request: Request):
    return JSONResponse(status_code=200, content=MAPS_GEOCODE_MOCK_DATA)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("kazoo_mobile_mock:app", host="0.0.0.0", port=5000, reload=True)
