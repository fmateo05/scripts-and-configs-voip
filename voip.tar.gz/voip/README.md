# monster-ui-voip

This is a sub application of [2600hz/monster-ui](https://github.com/2600hz/monster-ui).

Users should clone into `/monster-ui/src/apps/` such as:
```
$ cd monster-ui/src/apps/
$ git clone https://github.com/2600hz/monster-ui-voip.git voip
```
Then the gulp workflow for 2600hz/monster-ui applies.
